# 🏹 El Cazador Awajún

**El Cazador Awajún** es una versión cultural del clásico juego del ahorcado, ambientada en la selva amazónica con vocabulario del pueblo Awajún. Incluye **10 niveles**, pistas culturales y **imágenes locales** listas para Streamlit Cloud.

---

## 📂 Estructura del proyecto
```
cazador-awajun-completo/
├─ cazador_awajun_niveles.py
├─ requirements.txt
├─ .streamlit/
│  └─ config.toml
└─ imagenes/
   ├─ fondo_jungla.png
   ├─ cazador_6.png
   ├─ cazador_5.png
   ├─ cazador_4.png
   ├─ cazador_3.png
   ├─ cazador_2.png
   ├─ cazador_1.png
   └─ cazador_0.png
```
> Todas las imágenes incluidas fueron **generadas automáticamente** para que no dependas de enlaces externos.

---

## 🖥️ Ejecutar localmente
```bash
pip install -r requirements.txt
streamlit run cazador_awajun_niveles.py
```

---

## 🚀 Subir a GitHub (paso a paso)
1. Crea un repositorio nuevo (por ejemplo, `cazador-awajun`).
2. Sube **todos** los archivos y carpetas de este proyecto a la **raíz** del repo.
3. Desde tu carpeta local:
   ```bash
   git init
   git add .
   git commit -m "Inicial: El Cazador Awajún (Streamlit)"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/cazador-awajun.git
   git push -u origin main
   ```

---

## 🌐 Desplegar en Streamlit Cloud
1. Ve a https://streamlit.io/cloud e inicia sesión con GitHub.
2. Clic en **Deploy an app** → selecciona tu repo.
3. En **Main file path**, coloca: `cazador_awajun_niveles.py`
4. Branch: `main` → **Deploy**.
5. Streamlit instalará las dependencias y cargará las imágenes locales.

> **Importante:** No borres la carpeta `imagenes/` ni `.streamlit/`. El app usa esas rutas locales.

---

## ✏️ Personalizar
- Agrega más palabras Awajún en la lista `niveles`.
- Cambia el tema en `.streamlit/config.toml`.
- Reemplaza las imágenes en `imagenes/` (con los mismos nombres).

---

## 🪶 Créditos
Creado para promover el conocimiento del idioma Awajún y la cultura amazónica a través del aprendizaje interactivo.
