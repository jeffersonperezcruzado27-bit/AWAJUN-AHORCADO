import streamlit as st
import random
from pathlib import Path

# ==============================
# CONFIGURACIÓN INICIAL
# ==============================
st.set_page_config(page_title="El Cazador Awajún", page_icon="🏹", layout="centered")

# Fondo local (CSS con imagen)
fondo = (Path(__file__).parent / "imagenes" / "fondo_jungla.png").as_posix()
st.markdown(f"""
<style>
[data-testid="stAppViewContainer"] {{
    background-image: url('{fondo}');
    background-size: cover;
    background-position: center;
}}
[data-testid="stHeader"] {{background: rgba(0,0,0,0);}}
[data-testid="stToolbar"] {{visibility: hidden;}}
h1, h2, h3, p, span, div {{ color: white !important; }}
</style>
""", unsafe_allow_html=True)

st.title("🏹 El Cazador Awajún")
st.write("Acompaña al cazador Awajún en su viaje por la selva. Adivina las palabras en Awajún para avanzar por los niveles.")

# ==============================
# PALABRAS POR NIVEL
# ==============================
niveles = [
    ("wájin", "jabalí", "Animal fuerte de la selva"),
    ("apach", "mono", "Animal que salta entre los árboles"),
    ("yáká", "yuca", "Raíz que alimenta a la familia Awajún"),
    ("tsáim", "río", "Fuente de vida y caminos de agua"),
    ("átum", "fuego", "Elemento vital para cocinar y protegerse"),
    ("núwá", "mujer", "Figura importante en la familia Awajún"),
    ("bánan", "plátano", "Fruta cultivada en la selva"),
    ("táwen", "flor", "Símbolo de belleza natural"),
    ("nampet", "luna", "Brilla en la noche sobre la selva"),
    ("iwa", "pez", "Alimento que se pesca en el río"),
    ("japa", "sol", "Da energía y guía al cazador"),
    ("chiya", "estrella", "Brilla en el cielo nocturno"),
    ("páim", "montaña", "Lugar sagrado de los espíritus"),
    ("shuin", "niño", "Representa el futuro del pueblo"),
    ("yuwá", "casa", "Refugio de la familia"),
    ("tuná", "camino", "Conduce a nuevas aventuras"),
    ("ainchu", "loro", "Ave de colores vivos"),
    ("niim", "agua", "Fuente de vida para todos"),
    ("múun", "serpiente", "Habita entre las hojas de la selva"),
    ("tsátsam", "espíritu", "Protector del bosque"),
]

# ==============================
# ESTADO DEL JUEGO
# ==============================
if "nivel" not in st.session_state:
    st.session_state.nivel = 1
    st.session_state.intentos = 6
    st.session_state.letras_adivinadas = []
    st.session_state.mensaje = ""
    palabra, trad, pista = niveles[st.session_state.nivel - 1]
    st.session_state.palabra, st.session_state.traduccion, st.session_state.pista = palabra, trad, pista

# ==============================
# INFORMACIÓN DEL NIVEL
# ==============================
st.subheader(f"🌿 Nivel {st.session_state.nivel}/10")
palabra = st.session_state.palabra
palabra_mostrada = " ".join([letra if letra in st.session_state.letras_adivinadas else "_" for letra in palabra])
st.write(f"💡 Pista: {st.session_state.pista}")
st.write(f"❤️ Intentos restantes: {st.session_state.intentos}")
st.subheader(f"Palabra: {palabra_mostrada}")

# Imagen del cazador local según los intentos
img_paths = [f"imagenes/cazador_{i}.png" for i in range(6, -1, -1)]
st.image(img_paths[6 - st.session_state.intentos], use_container_width=True)

# ==============================
# ENTRADA DEL USUARIO
# ==============================
letra = st.text_input("Introduce una letra:", max_chars=1).lower()

if st.button("Adivinar"):
    if letra and letra.isalpha():
        if letra in palabra:
            if letra not in st.session_state.letras_adivinadas:
                st.session_state.letras_adivinadas.append(letra)
                st.session_state.mensaje = f"✅ ¡Bien hecho! La letra '{letra}' está en la palabra."
            else:
                st.session_state.mensaje = "⚠️ Ya habías usado esa letra."
        else:
            st.session_state.intentos -= 1
            st.session_state.mensaje = f"❌ La letra '{letra}' no está en la palabra."
    else:
        st.session_state.mensaje = "⚠️ Ingresa una letra válida."

st.write(st.session_state.mensaje)

# ==============================
# COMPROBAR RESULTADO
# ==============================
if "_" not in palabra_mostrada:
    st.success(f"🎉 ¡Nivel {st.session_state.nivel} completado! La palabra era '{palabra}' ({st.session_state.traduccion}).")
    if st.session_state.nivel < 10:
        if st.button("➡️ Siguiente nivel"):
            st.session_state.nivel += 1
            st.session_state.intentos = 6
            st.session_state.letras_adivinadas = []
            st.session_state.mensaje = ""
            palabra, trad, pista = niveles[st.session_state.nivel - 1]
            st.session_state.palabra, st.session_state.traduccion, st.session_state.pista = palabra, trad, pista
            st.experimental_rerun()
    else:
        st.balloons()
        st.success("🏆 ¡Felicidades! Has completado los 10 niveles del Cazador Awajún y te has convertido en un Gran Sabio de la Selva.")
        if st.button("🔁 Jugar de nuevo"):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.experimental_rerun()

elif st.session_state.intentos == 0:
    st.error(f"💀 El cazador se perdió en la selva... La palabra era '{palabra}' ({st.session_state.traduccion}).")
    if st.button("🔁 Intentar de nuevo"):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.experimental_rerun()
